import 'package:flutter/material.dart';
import 'package:classroom_prj/data/model/subject_stream.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';

class StreamType extends StatelessWidget {
  final SubjectStreamType type;

  const StreamType({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: (type == SubjectStreamType.material
                ? AppTheme.material
                : AppTheme.quiz)
            .withOpacity(0.15),
        borderRadius: BorderRadius.circular(360),
      ),
      child: Text(
        type == SubjectStreamType.material ? "Material" : "Quiz",
        style: TextStyle(
          color: type == SubjectStreamType.material
              ? AppTheme.material
              : AppTheme.quiz,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

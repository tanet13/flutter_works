import 'package:flutter/material.dart';
import 'package:classroom_prj/data/model/subject_assignment.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';

class AssignmentStatus extends StatelessWidget {
  final SubjectAssignmentType type;

  const AssignmentStatus({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(360),
          color: (type == SubjectAssignmentType.turnedIn
                  ? AppTheme.green
                  : AppTheme.red)
              .withOpacity(0.25)),
      child: Text(
        type == SubjectAssignmentType.turnedIn ? "Turned In" : "Missing",
        style: TextStyle(
          color: type == SubjectAssignmentType.turnedIn
              ? AppTheme.green
              : AppTheme.red,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

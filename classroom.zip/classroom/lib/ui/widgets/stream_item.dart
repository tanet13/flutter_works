import 'package:classroom_prj/data/model/subject_assignment.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:classroom_prj/data/model/subject_stream.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';
import 'package:classroom_prj/ui/widgets/stream_type.dart';
import 'package:intl/intl.dart';

class StreamItem extends StatelessWidget {
  final SubjectStream stream;
  final SubjectAssignment? assignment;

  const StreamItem({Key? key, required this.stream, this.assignment}): super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.dark, width: 1.3),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SvgPicture.asset(
                  stream.type == SubjectStreamType.material
                      ? "assets/icons/material.svg"
                      : "assets/icons/quiz.svg",
                  color: AppTheme.white,
                  width: 24,
                  height: 24,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        stream.title,
                        style: const TextStyle(
                          color: AppTheme.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        DateFormat("MMM dd").format(stream.postedAt),
                        style: const TextStyle(
                          color: AppTheme.grey,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                StreamType(type: stream.type),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

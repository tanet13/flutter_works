import 'package:flutter/material.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';

class CustomCheckBox extends StatefulWidget { 

  const CustomCheckBox({Key? key, 
    required this.text,
    this.onChanged,
    this.initialValue = false,
  }) : super(key: key);
  final String text;
  final Function(bool)? onChanged; 
  final bool initialValue;

  @override
  _CustomCheckBoxState createState() => _CustomCheckBoxState();
}

class _CustomCheckBoxState extends State<CustomCheckBox> {
  late bool _isSelected;

  @override
  void initState() {
    super.initState();
    _isSelected = widget.initialValue; 
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _isSelected = !_isSelected;
        });
        if (widget.onChanged != null) {
          widget.onChanged!(_isSelected); 
        }
      },
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: AppTheme.white),
            ),
            child: _isSelected
                ? const Icon(
                    Icons.check,
                    size: 17,
                    color: Colors.green,
                  )
                : null,
          ),
          const SizedBox(width: 12),
          Text(widget.text,style: const TextStyle(color: AppTheme.grey),),
        ],
      ),
    );
  }
}

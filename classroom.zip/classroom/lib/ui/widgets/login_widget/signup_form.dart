import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:classroom_prj/ui/theme/app_theme.dart';
import '../../views/login_view/login.dart';
import 'primary_button.dart'; 
import 'package:logging/logging.dart'; 


class SignUpForm extends StatefulWidget {
  const SignUpForm({Key? key}) : super(key: key);

  @override
  _SignUpFormState createState() => _SignUpFormState();
}

class _SignUpFormState extends State<SignUpForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  bool _isObscure = true;

  // สร้าง logger instance
  final Logger _logger = Logger('SignUpForm');

  Future<void> signUpWithEmailPassword(
      String email, String password, BuildContext context) async {
    try {
      final UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      // ใช้ logging แทน print
      _logger.info('User registered: ${userCredential.user?.email}');

      // Navigate to login screen or home screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (BuildContext context) => const LogInScreen()),
      );
    } catch (e) {
      // Logging error
      _logger.severe('Error during registration: $e');
      
      // แสดง error ผ่าน UI
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          buildInputForm('First Name', false, validateNotEmpty),
          buildInputForm('Last Name', false, validateNotEmpty),
          buildInputForm('Email', false, validateEmail),
          buildInputForm('Phone', false, validatePhone),
          buildInputForm('Password', true, validatePassword),
          buildInputForm('Confirm Password', true, validateConfirmPassword),
          const SizedBox(height: 20),
          PrimaryButton(
            buttonText: 'Sign Up',
            onTap: () async {
              if (_formKey.currentState!.validate()) {
                final String email = emailController.text.trim();
                final String password = passwordController.text.trim();

                // Call the sign-up function
                await signUpWithEmailPassword(email, password, context);
              } else {
                _logger.warning('Form is invalid');
              }
            },
          ),
        ],
      ),
    );
  }

  Padding buildInputForm(
      String hint, bool pass, String? Function(String?) validator) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: TextFormField(
        style: const TextStyle(color: AppTheme.white),
        controller: hint == 'Email'
            ? emailController
            : (hint == 'Password'
                ? passwordController
                : (hint == 'Confirm Password'
                    ? confirmPasswordController
                    : null)), 
        obscureText: pass ? _isObscure : false,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: AppTheme.grey),
          focusedBorder: const UnderlineInputBorder(
              borderSide: BorderSide(color: AppTheme.primary)),
          suffixIcon: pass
              ? IconButton(
                  onPressed: () {
                    setState(() {
                      _isObscure = !_isObscure;
                    });
                  },
                  icon: _isObscure
                      ? const Icon(
                          Icons.visibility_off,
                          color: AppTheme.grey,
                        )
                      : const Icon(
                          Icons.visibility,
                          color: AppTheme.primary,
                        ))
              : null,
        ),
        validator: validator,
      ),
    );
  }

  // ฟังก์ชันตรวจสอบฟิลด์ต่างๆ
  String? validateNotEmpty(String? value) {
    if (value == null || value.isEmpty) {
      return 'This field is required';
    }
    return null;
  }

  String? validateEmail(String? value) {
    const String emailPattern = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
    final RegExp regExp = RegExp(emailPattern);
    if (value == null || value.isEmpty) {
      return 'Email is required';
    } else if (!regExp.hasMatch(value)) {
      return 'Enter a valid email';
    }
    return null;
  }

  String? validatePhone(String? value) {
    if (value == null || value.isEmpty) {
      return 'Phone number is required';
    } else if (value.length != 10) {
      return 'Enter a valid phone number';
    }
    return null;
  }

  String? validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password is required';
    } else if (value.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return null;
  }

  String? validateConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Confirm your password';
    } else if (value != passwordController.text) {
      return 'Passwords do not match';
    }
    return null;
  }
}

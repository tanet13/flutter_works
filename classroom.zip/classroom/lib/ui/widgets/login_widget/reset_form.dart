import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart'; 

import 'package:classroom_prj/ui/theme/app_theme.dart';
import '../../views/login_view/login.dart';
import 'primary_button.dart';

class ResetForm extends StatelessWidget {
  ResetForm({Key? key}) : super(key: key);

  final TextEditingController emailController = TextEditingController();
  final Logger _logger = Logger('ResetForm');

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Column(
        children: [
          TextFormField(
            controller: emailController, 
            decoration: const InputDecoration(
              hintText: 'Email',
              hintStyle: TextStyle(color: AppTheme.grey),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppTheme.primary),
              ),
            ),
          ),
          const SizedBox(height: 20),
          PrimaryButton(
            buttonText: 'Reset Password',
            onTap: () async {
              await resetPassword(context);
            },
          ),
        ],
      ),
    );
  }

  Future<void> resetPassword(BuildContext context) async {
    final String email = emailController.text.trim();
    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your email address')),
      );
      _logger.warning('Email field is empty');
      return;
    }

    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password reset email sent!')),
      );
      _logger.info('Password reset email sent to $email');

      // นำทางกลับไปยังหน้าล็อกอิน
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (BuildContext context) => const LogInScreen()),
      );
    } catch (e) {
      _logger.severe('Failed to send password reset email: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }
}

import 'package:classroom_prj/ui/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';

import 'primary_button.dart';

class LogInForm extends StatefulWidget { 
  const LogInForm({
    Key? key, 
    required this.emailController,
    required this.passwordController,
    required this.onLogIn, 
  }) : super(key: key);

  final TextEditingController emailController;
  final TextEditingController passwordController;
  final Function(String email, String password) onLogIn;

  @override
  _LogInFormState createState() => _LogInFormState();
}

class _LogInFormState extends State<LogInForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final Logger _logger = Logger('LogInForm');
  bool _isObscure = true;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey, 
      child: Column(
        children: [
          buildInputForm(widget.emailController, 'Email', false, validateEmail),
          buildInputForm(widget.passwordController, 'Password', true, validatePassword),
          const SizedBox(height: 20),
          PrimaryButton(
            buttonText: 'Log In',
            onTap: () {
              if (_formKey.currentState!.validate()) {
                final String email = widget.emailController.text.trim();
                final String password = widget.passwordController.text.trim();
                widget.onLogIn(email, password); 
              } else {
                _logger.warning('Form is invalid');
              }
            },
          ),
        ],
      ),
    );
  }

  Padding buildInputForm(TextEditingController controller, String label, bool pass, String? Function(String?) validator) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: TextFormField(
        style: const TextStyle(color: AppTheme.white),
        controller: controller,
        obscureText: pass ? _isObscure : false,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: AppTheme.grey),
          focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: AppTheme.primary),
          ),
          suffixIcon: pass
              ? IconButton(
                  onPressed: () {
                    setState(() {
                      _isObscure = !_isObscure;
                    });
                  },
                  icon: _isObscure
                      ? const Icon(Icons.visibility_off, color: AppTheme.grey)
                      : const Icon(Icons.visibility, color: AppTheme.primary),
                )
              : null,
        ),
        validator: validator,
      ),
    );
  }

  String? validateEmail(String? value) {
    const String emailPattern = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
    final RegExp regExp = RegExp(emailPattern);
    if (value == null || value.isEmpty) {
      return 'Email is required';
    } else if (!regExp.hasMatch(value)) {
      return 'Enter a valid email';
    }
    return null;
  }

  String? validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password is required';
    } else if (value.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return null;
  }
}

import 'package:flutter/material.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';

class PrimaryButton extends StatelessWidget { 

  const PrimaryButton(
      {Key? key, required this.buttonText, required this.onTap}) : super(key: key);
  final String buttonText;
  final VoidCallback onTap; 

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
 
      onTap: onTap, 
      child: Container(
        alignment: Alignment.center,
        height: MediaQuery.of(context).size.height * 0.08,
        width: double.infinity,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16), color: AppTheme.primary),
        child: Text(
          buttonText,
          style: textButton.copyWith(color: AppTheme.white),
        ),
      ),
    );
  }
}

import 'dart:io';
// ignore: unused_import
import 'package:path/path.dart' as p;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

// ฟังก์ชันเปิด Dialog สำหรับเพิ่มลิงก์
Future<void> openDialog(
        BuildContext context, List<String> links, Function setState) =>
    showDialog(
      context: context,
      builder: (ctx) {
        String link = "";

        return AlertDialog(
          title: const Text("Add Link"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                onChanged: (value) {
                  link = value; 
                },
                decoration: const InputDecoration(
                  labelText: "Enter Link",
                  hintText: "https://example.com",
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              child: const Text("Cancel"),
              onPressed: () {
                Navigator.of(ctx).pop(); 
              },
            ),
            TextButton(
              child: const Text("Add"),
              onPressed: () {
                if (link.isNotEmpty && !links.contains(link)) {
                  setState(() {
                    links.add(link); 
                  });
                }
                Navigator.of(ctx).pop(); 
              },
            ),
          ],
        );
      },
    );

// ฟังก์ชันสำหรับบันทึกไฟล์ไปยังตำแหน่งใหม่
Future<File> saveFilePermanently(
    PlatformFile file, String newDirectoryPath) async {
  // ตรวจสอบว่า directory ที่ระบุมีอยู่หรือไม่
  final newDirectory = Directory(newDirectoryPath);
  if (!await newDirectory.exists()) {
    // สร้าง directory ใหม่ถ้ายังไม่มี
    await newDirectory.create(recursive: true);
  }

  // สร้างเส้นทางใหม่สำหรับไฟล์
  final newFilePath = '${newDirectory.path}/${file.name}';

  // ตรวจสอบว่า file.path ไม่เป็น null
  if (file.path != null) {
    // ย้ายไฟล์ไปยังเส้นทางใหม่
    return File(file.path!).copy(newFilePath);
  } else {
    throw Exception("File path is null");
  }
}

// คลาสสำหรับการส่งงาน
class AssignmentSubmission {
  final BuildContext context;
  final PlatformFile? selectedFile;
  final List<String> links;

  AssignmentSubmission({
    required this.context,
    required this.selectedFile,
    required this.links,
  });

  void submitAssignment() {
    if (selectedFile != null) { 
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'ส่งงานเรียบร้อย: ${selectedFile!.name}'),
          duration: const Duration(seconds: 2),
        ),
      );
    } else if (links.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('ส่งลิงค์เรียบร้อย: ${links.join(", ")}'),
          duration: const Duration(seconds: 2),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('กรุณาส่งงานก่อน'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }
}

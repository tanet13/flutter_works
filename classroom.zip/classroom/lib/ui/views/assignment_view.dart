import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import '../../data/model/subject_assignment.dart';
import '../theme/app_theme.dart';
import '../widgets/utility.dart';
import '../widgets/app_icon_buttton.dart';
import '../widgets/assignment_status.dart';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'package:flutter/foundation.dart' show kIsWeb;

bool isSubmitted = false;

class AssignmentView extends StatefulWidget {
  final SubjectAssignment assignment;

  const AssignmentView({Key? key, required this.assignment}) : super(key: key);

  @override
  _AssignmentViewState createState() => _AssignmentViewState();
}

class _AssignmentViewState extends State<AssignmentView> {
  PlatformFile? selectedFile;
  String? fileName; 
  final List<String> links = []; 

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          color: AppTheme.darkgrey,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(36),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: AppIconButton(
                      icon: SvgPicture.asset(
                        "assets/icons/back.svg",
                        width: 24,
                        height: 24,
                        color: AppTheme.white,
                      ),
                      onTap: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ),
                  Row(
                    children: [
                      SvgPicture.asset(
                        "assets/icons/assignment.svg",
                        color: AppTheme.white,
                        width: 55,
                        height: 55,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.assignment.title,
                              style: const TextStyle(
                                  color: AppTheme.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 55),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Due at ${DateFormat("MMM dd").format(widget.assignment.dueAt)}",
                              style: const TextStyle(
                                color: AppTheme.grey,
                                fontSize: 24,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                    ],
                  ),
                  const Divider(
                    color: Colors.black,
                    thickness: 2,
                    height: 20,
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: SizedBox(
                      height: 400,
                      width: 400,
                      child: Card(
                        color: AppTheme.grey,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 36,
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12)),
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text(
                                    "Your Work",
                                    style: TextStyle(
                                        color: AppTheme.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 24),
                                  ),
                                  AssignmentStatus(
                                      type: widget
                                          .assignment.type), // ใช้ค่าจาก object
                                ],
                              ),
                              const SizedBox(height: 12),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: AppTheme.white,
                                      elevation: 20,
                                    ),
                                    child: const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.add,
                                          color: AppTheme.primary,
                                          size: 24,
                                        ),
                                        Text(
                                          'Add Works',
                                          style: TextStyle(
                                              fontSize: 25,
                                              color: AppTheme.primary),
                                        ),
                                      ],
                                    ),
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            elevation: 20,
                                            backgroundColor: AppTheme.grey,
                                            title: const Text('Add Work'),
                                            content: Container(
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          24)),
                                              child: SizedBox(
                                                width: 150,
                                                height: 100,
                                                child: ListView(
                                                  children: [
                                                    ListTile(
                                                      title: const Text(
                                                          "Add File"),
                                                      onTap: () async {
                                                        // file picker
                                                        final result =
                                                            await FilePicker
                                                                .platform
                                                                .pickFiles();
                                                        if (result != null &&
                                                            result.files
                                                                .isNotEmpty) {
                                                          setState(() {
                                                            selectedFile =
                                                                result.files
                                                                    .first;
                                                            fileName = result
                                                                .files
                                                                .first
                                                                .name;
                                                          });

                                                          final file = result
                                                              .files.first;
                                                          // ignore: avoid_print
                                                          print(
                                                              'ไฟล์ที่เลือก: ${file.name}');

                                                          // บันทึกไฟล์
                                                          if (kIsWeb) {
                                                            final blob =
                                                                html.Blob([
                                                              file.bytes!
                                                            ]);
                                                            final url = html.Url
                                                                .createObjectUrlFromBlob(
                                                                    blob);
                                                            // ignore: unused_local_variable
                                                            final anchor = html
                                                                .AnchorElement(
                                                                    href: url)
                                                              ..setAttribute(
                                                                  'download',
                                                                  file.name)
                                                              ..click();
                                                            html.Url
                                                                .revokeObjectUrl(
                                                                    url);
                                                          }
                                                        }
                                                      },
                                                    ),
                                                    ListTile(
                                                      title: const Text(
                                                          "Add Link"),
                                                      onTap: () {
                                                        // เปิดป๊อปอัปเพื่อกรอกลิงก์
                                                        openDialog(context,
                                                            links, setState);
                                                      },
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            actions: [
                                              TextButton(
                                                child: const Text('Cancel'),
                                                onPressed: () {
                                                  Navigator.of(context)
                                                      .pop(); 
                                                },
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    },
                                  ),
                                  const SizedBox(height: 12),
                                  // แสดงลิงก์หรือไฟล์ที่เลือก
                                  Row(
                                    children: [
                                      if (isSubmitted)
                                        Expanded(
                       
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: links.map((link) {
                                              return Padding(
                                                padding: const EdgeInsets
                                                        .symmetric(
                                                    vertical:
                                                        8), 
                                                child: Container(
                                                  decoration:
                                                      const BoxDecoration(
                                                    color: AppTheme.dark,
                                                    borderRadius: BorderRadius
                                                        .all(Radius.circular(
                                                            8)), 
                                                  ),
                                                  padding: const EdgeInsets.all(
                                                      16), 
                                                  child: Text(
                                                    link,
                                                    style: const TextStyle(
                                                      color: AppTheme.white,
                                                      fontSize: 24,
                                                    ),
                                                  ),
                                                ),
                                              );
                                            }).toList(),
                                          ),
                                        ),
                                      if (isSubmitted && fileName != null)
                                        Expanded(
                                         
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical:
                                                    8), 
                                            child: Container(
                                              decoration: const BoxDecoration(
                                                color: AppTheme.dark,
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(8)),
                                              ),
                                              padding: const EdgeInsets.all(16),
                                              child: Text(
                                                'ไฟล์ที่เลือก: $fileName',
                                                style: const TextStyle(
                                                  color: AppTheme.white,
                                                  fontSize: 24,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ],
                              ),
                              const SizedBox(height: 24),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: AppTheme.primary,
                                    ),
                                    onPressed: () {
                                      if (!isSubmitted) {
                                        // ส่งงาน
                                        AssignmentSubmission submission =
                                            AssignmentSubmission(
                                                context: context,
                                                selectedFile:
                                                    selectedFile, 
                                                links: links);
                                        submission
                                            .submitAssignment(); 
                                        setState(() {
                                          isSubmitted =
                                              true; 
                                        });
                                      } else {
                                        // ยกเลิกงาน
                                        setState(() {
                                          isSubmitted = false;
                                          selectedFile =
                                              null; 
                                          links.clear();
                                        });
                                        // แสดงข้อความว่ายกเลิกงานแล้ว
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                            content:
                                                Text('ยกเลิกงานเรียบร้อยแล้ว'),
                                            duration: Duration(seconds: 2),
                                          ),
                                        );
                                      }
                                    },
                                    child: Text(
                                      isSubmitted
                                          ? 'Cancel Assignment'
                                          : 'Submit Assignment',
                                      style: const TextStyle(
                                          color: AppTheme.white),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

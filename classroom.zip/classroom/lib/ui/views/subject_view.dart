import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:classroom_prj/data/class_data.dart';
import 'package:classroom_prj/data/model/subject.dart';
import 'package:classroom_prj/data/model/subject_assignment.dart';
import 'package:classroom_prj/data/model/subject_stream.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';
import 'package:classroom_prj/ui/widgets/app_icon_buttton.dart';
import 'package:classroom_prj/ui/widgets/assignment_item.dart';
import 'package:classroom_prj/ui/widgets/stream_item.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import '../../data/apihelp.dart';
import '../../data/model/student.dart';


class SubjectView extends StatefulWidget {
  final Subject subject;

  const SubjectView({Key? key, required this.subject}) : super(key: key);

  @override
  State<SubjectView> createState() => _SubjectViewState();
}

class _SubjectViewState extends State<SubjectView> {
  int _activeIndex = 0;
  List<Student> students = []; 

  final APIhelp apiHelper = APIhelp(); 

  @override
  void initState() {
    super.initState();
    fetchStudents(); 
  }

  Future<void> fetchStudents() async {
    try {
      final response = await APIhelp.fetchStudents(); 
      setState(() {
        students = response;
      }); 
    } catch (e) {
      print("Error fetching students: $e"); 
    }
  }

  @override
  Widget build(BuildContext context) {
    final pageController = PageController();
    final subjectStreams =
        streams.where((item) => item.subjectId == widget.subject.id).toList();
    final List<Map<String, dynamic>> menus = [
      {'index': 1, 'icon': Icons.timer, 'title': "Stream"},
      {'index': 2, 'icon': Icons.assignment, 'title': "Assignment"},
      {'index': 3, 'icon': Icons.group, 'title': "Classmates"},
    ];

    final List<Widget> bodies = [
      StreamBody(streams: subjectStreams),
      AssignmentBody(
          assignments: assignments
              .where((item) => item.subjectId == widget.subject.id)
              .toList()),
      ClassmateBody(subjects: [widget.subject], students: students),
    ];

    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  AppIconButton(
                    icon: SvgPicture.asset(
                      "assets/icons/back.svg",
                      width: 24,
                      height: 24,
                      color: AppTheme.white,
                    ),
                    onTap: () {
                      Navigator.of(context).pop(); 
                    },
                  ),
                  const SizedBox(width: 16),
                ],
              ),
              GNav(
                selectedIndex: _activeIndex,
                curve: Curves.easeInOutQuint,
                duration: const Duration(milliseconds: 300),
                haptic: true,
                gap: 8,
                tabMargin: const EdgeInsets.symmetric(horizontal: 8),
                color: AppTheme.grey,
                activeColor: Theme.of(context).primaryColor,
                tabBackgroundColor:
                    Theme.of(context).primaryColor.withOpacity(0.25),
                onTabChange: (index) {
                  setState(() {
                    _activeIndex = index;
                    pageController.animateToPage(index,
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeInOutQuint);
                  });
                },
                tabs: menus
                    .map((menu) => GButton(
                          gap: 8,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          icon: menu['icon'],
                          text: menu['title'],
                          textStyle: TextStyle(
                              color: Theme.of(context).primaryColor,
                              fontWeight: FontWeight.w600),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: PageView.builder(
                  controller: pageController,
                  physics: const BouncingScrollPhysics(),
                  onPageChanged: (index) {
                    setState(() {
                      _activeIndex = index;
                    });
                  },
                  itemCount: bodies.length,
                  itemBuilder: (context, index) => bodies[index],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class StreamBody extends StatelessWidget {
  final List<SubjectStream> streams;

  const StreamBody({Key? key, required this.streams}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 16),
        Expanded(
          child: ListView.builder(
            physics: const BouncingScrollPhysics(),
            itemCount: streams.length,
            itemBuilder: (ctx, index) {
              final stream = streams[index];
              return StreamItem(stream: stream);
            },
          ),
        ),
      ],
    );
  }
}

class AssignmentBody extends StatelessWidget {
  final List<SubjectAssignment> assignments;

  const AssignmentBody({Key? key, required this.assignments}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 16),
        Expanded(
          child: ListView.builder(
            physics: const BouncingScrollPhysics(),
            itemCount: assignments.length,
            itemBuilder: (ctx, index) {
              final assignment = assignments[index];
              return AssignmentItem(assignment: assignment);
            },
          ),
        ),
      ],
    );
  }
}

class ClassmateBody extends StatelessWidget {
  final List<Subject> subjects; // รับ List ของ subjects มาด้วย
  final List<Student> students; // รับ List ของ students มาด้วย

  const ClassmateBody(
      {Key? key, required this.subjects, required this.students})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final subject = subjects.isNotEmpty ? subjects[0] : null;
    return Padding(
      padding: const EdgeInsets.all(36),
      child: Column(
        children: [
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Teacher",
              style: TextStyle(color: AppTheme.white, fontSize: 24),
            ),
          ),
          const Divider(color: Colors.black, thickness: 2, height: 20),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              // ignore: unnecessary_string_interpolations
              "${subject?.lecturer ?? 'Unknown Teacher'}",
              style: const TextStyle(color: AppTheme.white, fontSize: 24),
            ),
          ),
          const Divider(color: Colors.black, thickness: 2, height: 20),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Classmates",
              style: TextStyle(color: AppTheme.white, fontSize: 24),
            ),
          ),
          const Divider(color: Colors.black, thickness: 2, height: 20),
          const SizedBox(height: 16),
          Expanded(
            child: students.isNotEmpty // ตรวจสอบว่ามีนักเรียนในลิสต์หรือไม่
                ? ListView.separated(
                    physics: const BouncingScrollPhysics(),
                    itemCount: students.length,
                    itemBuilder: (ctx, index) {
                      final student = students[index];
                      return ListTile(
                        title: Text(
                          student.email,
                          style: const TextStyle(
                              color: AppTheme.white, fontSize: 32),
                        ),
                      );
                    },
                    separatorBuilder: (ctx, index) => const Divider(
                      color: Colors.black,
                      thickness: 1.3,
                      height: 1,
                    ),
                  )
                : const Center(
                    child: Text(
                        "No classmates found.")), // แสดงข้อความเมื่อไม่มีนักเรียน
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import '../../widgets/login_widget/reset_form.dart';


class ResetPasswordScreen extends StatelessWidget {
  const ResetPasswordScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: appDefaultPadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 250),
            Text('Reset Password', style: titleText),
            const SizedBox(height: 5),
            Text(
              'Please enter your email address',
              style: subTitle.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            ResetForm(),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

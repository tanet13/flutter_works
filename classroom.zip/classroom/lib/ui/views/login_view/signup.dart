import 'package:flutter/material.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';
import '../../widgets/login_widget/checkbox.dart';
import '../../widgets/login_widget/signup_form.dart';
import 'login.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 70),
            Padding(
              padding: appDefaultPadding,
              child: Text('Create Account', style: titleText),
            ),
            const SizedBox(height: 5),
            Padding(
              padding: appDefaultPadding,
              child: Row(
                children: [
                  Text('Already a member?', style: subTitle),
                  const SizedBox(width: 5),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => const LogInScreen()));
                    },
                    child: Text(
                      'Log In',
                      style: textButton.copyWith(
                        decoration: TextDecoration.underline,
                        decorationThickness: 1,
                      ),
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: appDefaultPadding,
              child: const SignUpForm(),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: appDefaultPadding,
              child: const CustomCheckBox(text: 'Agree to terms and conditions.'),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: appDefaultPadding,
              child: const CustomCheckBox(text: 'I have at least 18 years old.'),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

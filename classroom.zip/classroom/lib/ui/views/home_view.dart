import 'package:flutter/material.dart';
import 'package:classroom_prj/data/home_data.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';
import 'package:classroom_prj/ui/views/subject_view.dart';
import 'package:classroom_prj/ui/widgets/subject_item.dart';

class HomeView extends StatelessWidget {
  const HomeView({Key? key}) : super(key: key);

  //ไว้เปลี่ยนตามเวลา
  String getGreetingMessage() {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return "Morning";
    } else if (hour < 17) {
      return "Afternoon";
    } else {
      return "Evening";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(360),
                child: Image.asset(
                  "assets/images/user.png",
                  width: 40,
                  height: 40,
                ),
              ),
            ),
            const SizedBox(height: 32),
            Align(
              alignment: Alignment.centerLeft,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RichText(
                    text: TextSpan(
                      style: const TextStyle(
                        fontSize: 24,
                        color: AppTheme.white,
                      ),
                      children: [
                        TextSpan(
                          // ด้วยฟังก์ชัน getGreetingMessage() ทำให้มันเปลี่ยน text ตามเวลาได้
                          text: " ${getGreetingMessage()} ",
                          style: const TextStyle(
                            color: AppTheme.white,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                        const TextSpan(
                          text: "Tanet ",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const TextSpan(
                          text: "👋🏼",
                          style: TextStyle(
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.6,
                    child: const Text(
                      "Never underestimate yourself, you've came this far",
                      style: TextStyle(
                        color: AppTheme.grey,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            const Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                /*Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "View all",
                      style: TextStyle(
                        color: AppTheme.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    
                  ],
                ),*/
                SizedBox(height: 16),
              ],
            ),
            const SizedBox(height: 32),
            Expanded(
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                itemCount: subjects.length,
                itemBuilder: (ctx, index) {
                  final subject = subjects[index];

                  // Subject Item
                  return GestureDetector(
                    onTap: () {
                      // Navigate to subject view
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => SubjectView(subject: subject),
                        ),
                      );
                    },
                    child: SubjectItem(subject: subject),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

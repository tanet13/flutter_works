//import 'package:classroom_prj/ui/views/home_view.dart';
import 'package:flutter/material.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:classroom_prj/ui/views/login_view/login.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: const FirebaseOptions(
    apiKey: 'AIzaSyDujGhkUw1UL-kD2Bp22GUMwxdi6kPKx_g',
    appId: '1:984576650238:android:b12bdd9325561a97966eaf',
    messagingSenderId: '',
    projectId: 'flutter-project-facaf',
  ));
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

/*void main() {
  runApp(const MyApp());
}*/

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Classroom_prj',
      theme: ThemeData(
        canvasColor: AppTheme.darkgrey,
        fontFamily: "Inter",
      ),
      home: const LogInScreen(),
      //home: const HomeView(),
    );
  }
}

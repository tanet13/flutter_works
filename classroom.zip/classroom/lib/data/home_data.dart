import 'package:classroom_prj/data/model/subject.dart';
import 'package:classroom_prj/ui/theme/app_theme.dart';

final List<Subject> subjects = [
  Subject(
    id: 1,
    slug: "digital-arts",
    name: "Digital Arts",
    desc: "Become a proficient Digital Artist",
    lecturer: "Prof. Josh Kurtman",
    image: "assets/images/digital_arts.png",
    gradient: [AppTheme.redGradientStart, AppTheme.redGradientEnd],
  ),
  Subject(
    id: 2,
    slug: "network-security",
    name: "Network Security",
    desc: "Securing network, securing the world",
    lecturer: "Prof. Yelena Karpov",
    image: "assets/images/network_security.png",
    gradient: [AppTheme.cyanGradientStart, AppTheme.cyanGradientEnd],
  ),
  Subject(
    id: 3,
    slug: "finance",
    name: "Finance",
    desc: "Let's achieve financial freedom!",
    lecturer: "Maria Inge",
    image: "assets/images/finance.png",
    gradient: [AppTheme.orangeGradientStart, AppTheme.orangeGradientEnd],
  ),
  Subject(
    id: 4,
    slug: "mobile-dev",
    name: "Mobile Dev",
    desc: "Develop miracle within your grip",
    lecturer: "Prof. Jorgen Faucsh",
    image: "assets/images/mobile_dev.png",
    gradient: [AppTheme.pinkGradientStart, AppTheme.pinkGradientEnd],
  ),
];

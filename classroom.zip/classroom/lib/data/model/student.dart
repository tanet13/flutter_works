

class Student {
  final String email;
  Student({required this.email});
}

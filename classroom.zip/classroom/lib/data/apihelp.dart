import 'dart:convert';
import 'package:http/http.dart' as http;
import 'model/student.dart';

class APIhelp {
  static Future<List<Student>> fetchStudents() async {
    const url = 'https://randomuser.me/api/?results=10';
    final uri = Uri.parse(url);

    try {
      final response = await http.get(uri);
      if (response.statusCode == 200) {
        final body = response.body;
        final json = jsonDecode(body);
        final results = json['results'] as List<dynamic>;

        // แปลง JSON เป็นลิสต์ของ Student objects
        final students = results.map((e) {
          return Student(
            email: e['email'],
          );
        }).toList();

        return students; // คืนค่าลิสต์ของ Student objects
      } else {
        // ignore: avoid_print
        print('Error fetching students: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      // ignore: avoid_print
      print('Exception: $e');
      return [];
    }
  }
}
